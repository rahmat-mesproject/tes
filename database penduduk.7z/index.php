<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="CSSPENDUDUK.CSS">
<title>Data Penduduk</title>
</head>

<body>
<form method="POST" enctype="multipart/form-data" action="upload_data.php">
	pilih file
	<input name="datapenduduk" type="file" required="required" accept=".xls"><br>
	<input name="upload" type="submit" value="import">
</form>
	<h1> Data Penduduk </h1>
<table>


<tr>
<th>N0</th>	
<th> Nama </th>
<th> No KTP </th>
<th> No KK </th>
<th> No HP </th>
</tr>
<?php
include 'koneksi.php';
$no = 1;
$data = mysql_query($koneksi,"select * from datapenduduk");
while ($d = mysqli_fetch_array($data)) {
	?>
<tr>
	<td><?php echo $no++; ?></td> 
<td><?php echo $d['nama']; ?></td>
<td><?php echo $d['noktp']; ?></td>
<td><?php echo $d['nokk']; ?> </td>
<td><?php echo $d['nohp']; ?> </td> 
</tr>

	<?php
}
?>




</table>
</body>

</html>